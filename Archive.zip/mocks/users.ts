import { User } from "@/types";

export const registeredUsers: User[] = [
  {
    name: "John Doe",
    email: "johndoe@gmail.com",
    password: "password",
  },
  {
    name: "Jane Doe",
    email: "janedoe@gmail.com",
    password: "password",
  },
];
